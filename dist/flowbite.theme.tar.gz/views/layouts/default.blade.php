@include('flowbite.partials.meta')

@include('flowbite.partials.header')

<main class="main-content">
    @yield('content')
</main>

@include('flowbite.partials.footer')


